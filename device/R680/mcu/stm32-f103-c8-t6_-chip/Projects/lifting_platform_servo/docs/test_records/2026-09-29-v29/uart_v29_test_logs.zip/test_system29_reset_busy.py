﻿import sys, time, json
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0, str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial, lift_uart_client as p

with Path('build/system29-reset-busy.jsonl').open('w') as out:
 def event(kind, **v):
  row = {'kind':kind, 'time':time.time(), **v}
  out.write(json.dumps(row)+'\n'); out.flush()
  if kind != 'telemetry': print(row, flush=True)
 def sample(t): event('telemetry', **asdict(t))
 def ack(a): event('ack', **asdict(a))
 with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as port:
  c=p.LiftClient(port)
  try:
   c.wait_ready(timeout=15,on_sample=sample);c.connect()
   c.request(p.OPCODES['move'],20000,on_sample=sample,on_ack=ack)
   deadline=time.monotonic()+4
   while time.monotonic()<deadline:
    c.monitor(.1,sample)
    if c.latest and c.latest.flags & 12 and abs(c.latest.speed_rpm)>10:break
   assert c.latest and c.latest.flags & 12 and abs(c.latest.speed_rpm)>10
   before=c.latest.uptime_ms
   try:
    c.request(p.OPCODES['reset'],p.RESET_KEY,on_sample=sample,on_ack=ack)
    raise AssertionError('RESET accepted during motion')
   except p.LiftError as error:
    assert 'result 0x83' in str(error), str(error)
    event('busy_rejected',message=str(error))
   # Client abandons the rejected request's session, stopping its motion.
   c.request(p.OPCODES['stop'],on_sample=sample,on_ack=ack)
   c.wait_ready(timeout=15,on_sample=sample)
   assert c.latest.uptime_ms>before,'unexpected reboot'
   c.connect()
   c.request(p.OPCODES['home'],on_sample=sample,on_ack=ack)
   c.wait_reached(0,timeout=30,on_sample=sample)
   c.wait_ready(timeout=10,on_sample=sample)
   event('PASS',final_um=c.latest.current_um)
  except BaseException as error:
   event('FAILED',error=repr(error))
   try:c.request(p.OPCODES['stop'])
   except BaseException:pass
   raise
  finally:
   c.close();c.monitor(.4,sample)

