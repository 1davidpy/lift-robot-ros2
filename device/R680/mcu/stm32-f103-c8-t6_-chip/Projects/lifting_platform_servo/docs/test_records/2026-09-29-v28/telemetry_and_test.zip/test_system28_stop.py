import sys,time,json
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
rows=[];events=[]
def observe(t):
 rows.append(asdict(t))
 if t.fault or not t.flags&1 or t.flags&128:raise p.LiftError('unsafe state')
def event(name,**kw):
 events.append({'name':name,'host_time':time.monotonic(),**kw})
 print(events[-1],flush=True)
with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as port:
 c=p.LiftClient(port)
 try:
  c.monitor(.5,observe);assert not c.latest.flags&12
  c.connect();c.monitor(.2,observe)
  if abs(c.latest.current_um)>10:
   c.request(p.OPCODES['home'],on_sample=observe);c.wait_reached(0,timeout=30,on_sample=observe);c.monitor(1.3,observe)
  c.request(p.OPCODES['move'],80000,on_sample=observe);c.monitor(.2,observe)
  deadline=time.monotonic()+8
  while c.latest.current_um<10000 or abs(c.latest.speed_rpm)<500:
   assert time.monotonic()<deadline,'motion did not start'
   c.monitor(.05,observe)
  event('stop_request',sample=asdict(c.latest))
  c.request(p.OPCODES['stop'],on_sample=observe);c.monitor(.2,observe)
  deadline=time.monotonic()+6
  while c.latest.flags&12 or abs(c.latest.speed_rpm)>2:
   assert time.monotonic()<deadline,'STOP did not settle'
   c.monitor(.1,observe)
  c.monitor(.3,observe);event('stopped_locked',sample=asdict(c.latest))
  assert 0<c.latest.current_um<80000,'STOP did not interrupt before the target'
  c.monitor(1.3,observe)
  c.request(p.OPCODES['home'],on_sample=observe)
  c.wait_reached(0,timeout=30,on_sample=observe);c.monitor(1.3,observe)
  assert abs(c.latest.current_um)<=10 and not c.latest.flags&12
  event('home_reached',sample=asdict(c.latest));status='PASS'
 except BaseException as e:
  status='FAILED';event('error',error=repr(e))
  try:c.request(p.OPCODES['stop'])
  except BaseException:pass
 finally:
  c.close();c.monitor(.5,observe)
  Path('build/system28-stop-test.json').write_text(json.dumps({'status':status,'events':events,'telemetry':rows},indent=2))
print(status,flush=True)
