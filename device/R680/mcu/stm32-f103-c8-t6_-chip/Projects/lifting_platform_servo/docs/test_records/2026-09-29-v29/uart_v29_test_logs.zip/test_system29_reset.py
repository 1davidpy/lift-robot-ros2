import sys,time,json
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
out=Path('build/system29-reset-motion.jsonl').open('w')
def event(kind,**v):
 row={'kind':kind,'time':time.time(),**v};out.write(json.dumps(row)+'\n');out.flush()
 if kind!='telemetry': print(row,flush=True)
def sample(t):
 event('telemetry',**asdict(t))
def ack(a): event('ack',**asdict(a))
with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as port:
 c=p.LiftClient(port)
 try:
  c.wait_ready(timeout=30,on_sample=sample);c.connect()
  c.request(p.OPCODES['move'],20000,on_sample=sample,on_ack=ack)
  c.wait_reached(20000,timeout=30,on_sample=sample);c.wait_ready(timeout=10,on_sample=sample)
  c.monitor(.2,sample);old_uptime=c.latest.uptime_ms
  event('before_reset',uptime=old_uptime)
  c.request(p.OPCODES['reset'],p.RESET_KEY,on_ack=ack,on_sample=sample)
  deadline=time.monotonic()+10; restarted=False
  while time.monotonic()<deadline:
   try:c.monitor(.1,sample)
   except p.LiftError as error:
    if 'restarted' not in str(error):raise
    restarted=True;c=p.LiftClient(port);break
   if c.latest and c.latest.uptime_ms<old_uptime:
    restarted=True;break
  assert restarted,'no reboot observed'
  event('restart_observed')
  reached=c.wait_ready(timeout=45,on_sample=sample)
  c.connect()
  reached=c.wait_reached(0,timeout=10,on_sample=sample)
  event('auto_home_pass',**asdict(reached))
  for target in (-20000,0):
   c.wait_ready(timeout=10,on_sample=sample)
   c.request(p.OPCODES['move'],target,on_sample=sample,on_ack=ack)
   c.wait_reached(target,timeout=30,on_sample=sample)
  c.wait_ready(timeout=10,on_sample=sample);event('PASS')
 except BaseException as e:
  event('FAILED',error=repr(e))
  try:c.request(p.OPCODES['stop'])
  except BaseException:pass
 finally:
  c.close();c.monitor(.5,sample);out.close()
