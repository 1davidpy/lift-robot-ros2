from pathlib import Path
import sys,json
from dataclasses import asdict
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as port:
 c=p.LiftClient(port)
 samples=[]
 c.wait_ready(timeout=15,on_sample=lambda t:samples.append(asdict(t)))
 config={str(i):c.request(p.OPCODES['info'],i).value for i in range(31)}
 c.monitor(3,lambda t:samples.append(asdict(t)))
 assert config['1']==29 and config['4']==2 and config['5']&8 and config['25']==1
 assert c.latest.current_um==0 and c.latest.speed_rpm==0 and c.latest.fault==0
 assert c.latest.flags&1 and not c.latest.flags&140
 record={'configuration':config,'samples':samples,'final':asdict(c.latest)}
 Path('build/system29-final-read.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 print(json.dumps({'configuration':config,'final':asdict(c.latest)}))
