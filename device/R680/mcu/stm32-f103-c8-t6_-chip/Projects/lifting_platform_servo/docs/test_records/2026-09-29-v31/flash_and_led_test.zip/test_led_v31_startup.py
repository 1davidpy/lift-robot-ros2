from pathlib import Path
from dataclasses import asdict
import sys, json, subprocess, time
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
cli=r'C:\Users\xiaofang\AppData\Local\stm32cube\bundles\programmer\2.23.0\bin\STM32_Programmer_CLI.exe'
samples=[]
with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as port:
 c=p.LiftClient(port)
 with open('build/led-v31-reset.log','w') as log:
  subprocess.run([cli,'-c','port=SWD','mode=HOTPLUG','freq=100','-rst'],stdout=log,stderr=subprocess.STDOUT,check=True)
 c.wait_ready(timeout=30,on_sample=lambda t:samples.append(asdict(t)))
 config={str(i):c.request(p.OPCODES['info'],i).value for i in (0,1,2,3,4,5,6,9,25,26,28,29,30)}
 c.monitor(3,lambda t:samples.append(asdict(t)))
 assert config['1']==31 and config['4']==2 and config['25']==1
 assert c.latest.current_um==0 and c.latest.speed_rpm==0 and not c.latest.fault
 assert c.latest.flags&1 and not c.latest.flags&140
 Path('build/led-v31-startup.json').write_text(json.dumps({'configuration':config,'samples':samples,'final':asdict(c.latest)},indent=2),encoding='utf-8')
 print(json.dumps({'PASS':True,'configuration':config,'final':asdict(c.latest)}))
