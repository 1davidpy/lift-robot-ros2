from pathlib import Path
from dataclasses import asdict
import sys,json,subprocess,re,time,statistics
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
cli=r'C:\Users\xiaofang\AppData\Local\stm32cube\bundles\programmer\2.23.0\bin\STM32_Programmer_CLI.exe'
nm=r'C:\Users\xiaofang\AppData\Local\stm32cube\bundles\gnu-tools-for-stm32\14.3.1+st.2\bin\arm-none-eabi-nm.exe'
symbols=subprocess.check_output([nm,'-n','build/lifting-platform-servo-release/lifting_platform_servo.elf'],text=True)
tick=int(re.search(r'^([0-9a-fA-F]+)\s+\w\s+xTickCount$',symbols,re.M)[1],16)
command=[cli,'-c','port=SWD','mode=HOTPLUG','freq=100',
         '-r32',hex(tick),'4','-r32','0x40010C04','12','-r32',hex(tick),'4']
pins=[];telemetry=[]
with serial.Serial('COM5',115200,timeout=.01,write_timeout=.2) as port:
 c=p.LiftClient(port)
 started=time.monotonic()
 while time.monotonic()-started<9:
  c.monitor(.015,lambda t:telemetry.append(asdict(t)))
  result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=3,check=True)
  raw=result.stdout.decode('utf-8',errors='replace')
  clock=[int(v,16) for v in re.findall(rf'^0x{tick:08X}\s*:\s*([0-9A-Fa-f]+)',raw,re.M|re.I)]
  gpio=re.search(r'^0x40010C04\s*:\s*([0-9A-Fa-f]+)\s+([0-9A-Fa-f]+)\s+([0-9A-Fa-f]+)',raw,re.M|re.I)
  assert len(clock)==2 and gpio,raw
  crh,idr,odr=[int(v,16) for v in gpio.groups()]
  assert ((crh>>16)&0xFFF)==0x822,'PB12/PB13 must be outputs and PB14 input'
  assert not (idr^odr)&0x3000,'LED pin voltage disagrees with output latch'
  pins.append({'tick_ms':sum(clock)/2,'read_window_ms':clock[1]-clock[0],
               'crh':crh,'idr':idr,'odr':odr,'led1_on':not bool(odr&0x1000),'led2_on':not bool(odr&0x2000)})
 c.monitor(.5,lambda t:telemetry.append(asdict(t)))
 config={str(i):c.request(p.OPCODES['info'],i).value for i in (1,25,28,29)}
 assert config=={'1':31,'25':1,'28':0,'29':0},config
 assert c.latest.current_um==0 and not c.latest.flags&140 and not c.latest.fault
summary={}
for led in ('led1_on','led2_on'):
 edges=[b['tick_ms'] for a,b in zip(pins,pins[1:]) if a[led]!=b[led]]
 rising=[b['tick_ms'] for a,b in zip(pins,pins[1:]) if not a[led] and b[led]]
 assert len(edges)>=12 and len(rising)>=6,(led,edges)
 halves=[b-a for a,b in zip(edges,edges[1:])]
 periods=[b-a for a,b in zip(rising,rising[1:])]
 assert all(350<=x<=650 for x in halves),halves
 assert all(850<=x<=1150 for x in periods),periods
 summary[led]={'edges':len(edges),'median_half_period_ms':statistics.median(halves),
               'median_period_ms':statistics.median(periods),'periods_ms':periods}
assert all(v['led1_on']==v['led2_on'] for v in pins)
record={'PASS':True,'summary':summary,'configuration':config,'pins':pins,'telemetry':telemetry}
Path('build/led-v31-pin-test.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({'PASS':True,'samples':len(pins),'summary':summary,'configuration':config}))
