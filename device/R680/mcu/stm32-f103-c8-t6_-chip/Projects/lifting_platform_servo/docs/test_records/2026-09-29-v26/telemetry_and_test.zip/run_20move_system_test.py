"""Attended 20-move hardware endurance test; never changes calibration."""
import sys,time,json,statistics
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path('Projects/lifting_platform_servo/tools').resolve()))
import serial,lift_uart_client as p
run_dir=Path('build/system-test-20260929-'+time.strftime('%H%M%S'));run_dir.mkdir()
print('LOG_DIR',run_dir,flush=True)
log=(run_dir/'telemetry.jsonl').open('w',encoding='utf-8')
summary={'port':'COM5','targets_mm':[20,0,-20,0,100,-100,160,-160,180,-180,180,-180,0,180,0,-180,180,-180,50,0],'completed':[],'status':'RUNNING'}
cycle=0; all_samples=[]; cycle_samples=[]; last_rx=None; preparing=False; prepare_start=0; prepare_position=0

def emit(kind,**values):
 row={'kind':kind,'wall_time':time.strftime('%Y-%m-%d %H:%M:%S'),'cycle':cycle,**values}
 log.write(json.dumps(row)+'\n');log.flush()
 if kind!='telemetry':print(json.dumps(row),flush=True)
def save(): (run_dir/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
def observe(t):
 global last_rx
 now=time.monotonic();emit('telemetry',**asdict(t));all_samples.append(t);cycle_samples.append(t)
 if last_rx is not None and now-last_rx>.5:raise p.LiftError('telemetry gap exceeded 500 ms')
 last_rx=now
 if t.feedback_age_at(now)>500:
  locked_preparation = preparing and now-prepare_start<2.0 and not t.flags&4 and abs(t.speed_rpm)<=2 and abs(t.current_um-prepare_position)<=10 and t.feedback_age_at(now)<=1500
  if not locked_preparation:raise p.LiftError('motor feedback stale outside locked preparation')
 if t.fault or t.flags&128 or not t.flags&1:raise p.LiftError('drive fault/inhibit/position invalid')
 if c.session and not t.flags&64:raise p.LiftError('session flag lost')
 if t.guard&28:raise p.LiftError('UART parser/overflow/transmit diagnostic error')
 if abs(t.current_um)>180100:raise p.LiftError('software envelope exceeded by over 0.1 mm')
 if abs(t.speed_rpm)>3300:raise p.LiftError('observed speed exceeds 3300 rpm')
 if cycle and not preparing and t.target_status>=0xe0:raise p.LiftError('motion canceled/rejected')
with serial.Serial('COM5',115200,timeout=.02,write_timeout=.2) as s:
 c=p.LiftClient(s)
 try:
  cfg=c.read_configuration();summary['configuration']=cfg
  assert cfg['protocol_version']==1 and cfg['firmware_version']>=26
  assert cfg['min_um']==-180000 and cfg['max_um']==180000
  assert cfg['absolute_stage']==2 and cfg['saved_mask']&4 and cfg['cruise_rpm']==3000
  c.monitor(.6,observe)
  assert c.latest and not c.latest.flags&12,'not stationary/locked before start'
  assert abs(c.latest.current_um)<=100,'expected start at center'
  emit('connected',ack=asdict(c.connect()));c.monitor(.3,observe)
  for cycle,target in enumerate(summary['targets_mm'],1):
   cycle_samples=[];start=c.latest.current_um;started=time.monotonic()
   assert abs(start-target*1000)>=1000,'no-op move cannot count'
   emit('move_start',from_um=start,target_mm=target)
   preparing=True;prepare_start=time.monotonic();prepare_position=start
   ack=c.request(p.OPCODES['home'] if target==0 else p.OPCODES['move'],0 if target==0 else target*1000,on_sample=observe)
   preparing=False
   emit('command_ack',**asdict(ack))
   reached=c.wait_reached(target*1000,timeout=90,on_sample=observe)
   # HOME requires the firmware's 1200 ms stationary dwell after the stop.
   c.monitor(1.3,observe)
   final=c.latest
   assert abs(final.current_um-target*1000)<=10 and not final.flags&12,'settling/lock check failed'
   result={'index':cycle,'start_um':start,'target_mm':target,'final_um':final.current_um,'error_um':final.current_um-target*1000,'duration_s':round(time.monotonic()-started,3),'peak_rpm':max(abs(t.speed_rpm) for t in cycle_samples),'samples':len(cycle_samples),'max_motor_age_ms':max(t.feedback_age_ms for t in cycle_samples),'brake_released_seen':any(t.flags&4 for t in cycle_samples)}
   assert result['brake_released_seen'],'actual movement not observed'
   summary['completed'].append(result);emit('move_pass',**result);save()
  cycle=0
  c.close();c.monitor(.5,observe)
  summary['status']='PASS';summary['host_crc_errors']=c.parser.errors
  summary['last_telemetry']=asdict(c.latest);summary['sample_count']=len(all_samples)
  assert c.parser.errors==0,'host CRC errors'
  emit('PASS',completed=len(summary['completed']),samples=len(all_samples))
 except BaseException as e:
  summary['status']='FAILED';summary['error']=repr(e);emit('FAILED',error=repr(e))
  try:emit('stop_ack',**asdict(c.request(p.OPCODES['stop'],timeout=2)))
  except BaseException as stop_error:emit('stop_error',error=repr(stop_error))
  try:c.close()
  except BaseException:pass
  # Continue recording after STOP without invoking motion acceptance checks.
  try:c.monitor(2,lambda t:emit('post_stop',**asdict(t)))
  except BaseException:pass
 finally:
  save();log.close()
print('FINAL',summary['status'],len(summary['completed']),str(run_dir),flush=True)
sys.exit(0 if summary['status']=='PASS' else 1)
