// SDK-side relay: HTTP confirms ARM/stop; ordered UDP carries velocity.
#include "luxi_lift_robot/carrier.hpp"
#include <httplib.h>
#include <nlohmann/json.hpp>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <atomic>
#include <csignal>
#include <iomanip>
#include <random>
#include <sstream>
#ifdef LUXI_LOCAL_ROS_SDK
namespace luxi_lift_robot {std::string local_sdk_request(const char *,const std::string &);}
#endif
using Json=nlohmann::json;
static std::atomic<bool> running{true};
static void shutdown_signal(int) {running.store(false);}
int main(int argc,char **argv) {
  const int sdk_port=argc>1?std::stoi(argv[1]):8000;
  const int port=argc>2?std::stoi(argv[2]):18031;
  luxi_lift_robot::Carrier carrier("lift_robot","127.0.0.1",sdk_port,"");
  httplib::Server server;
  std::mutex session_mutex;
  std::string token,owner_ip;
  unsigned long long highest=0;
  const int udp=socket(AF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
  sockaddr_in address{};address.sin_family=AF_INET;address.sin_port=htons(port+1);
  address.sin_addr.s_addr=htonl(INADDR_ANY);
  timeval timeout{0,100000};
  if(udp<0||bind(udp,reinterpret_cast<sockaddr*>(&address),sizeof(address))<0) return 2;
  setsockopt(udp,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
  server.set_payload_max_length(8192);
  server.Get("/api/state",[&](const httplib::Request &,httplib::Response &res) {
#ifdef LUXI_LOCAL_ROS_SDK
    try {res.set_content(luxi_lift_robot::local_sdk_request("/api/state",""),"application/json");}
    catch(const std::exception &e) {res.status=503;res.set_content(Json{{"message",e.what()}}.dump(),"application/json");}
#else
    httplib::Client sdk("127.0.0.1",sdk_port);
    sdk.set_connection_timeout(0,100000);sdk.set_read_timeout(0,150000);
    const auto reply=sdk.Get("/api/state");
    res.status=reply?reply->status:503;res.set_content(reply?reply->body:"{}","application/json");
#endif
  });
  server.Get("/api/relay/status",[&](const httplib::Request &,httplib::Response &res) {
    auto value=Json::parse(carrier.status().body);value["heartbeat_timeout_ms"]=1000;
    res.set_content(value.dump(),"application/json");
  });
  server.Post("/api/keyboard",[&](const httplib::Request &req,httplib::Response &res) {
    const auto body=Json::parse(req.body,nullptr,false);
    if(!body.is_object()||!body.contains("command")||!body["command"].is_string()) {res.status=400;return;}
    std::lock_guard<std::mutex> session(session_mutex);
    const auto command=body["command"].get<std::string>();
    luxi_lift_robot::Reply reply{400,"{}"};
    if(command=="keyboard_start"||command=="navigation_start") {
      if(Json::parse(carrier.status().body).value("armed",false)) {
        res.status=409;res.set_content("{\"success\":false,\"message\":\"relay already owned\"}","application/json");return;
      }
      reply=carrier.control("acquire",Json{{"client_id","atlas-relay"},{"navigation",command=="navigation_start"}}.dump());
      if(reply.status==200) {
        std::random_device random;std::ostringstream nonce;
        nonce<<std::hex<<std::setfill('0');for(int i=0;i<4;++i) nonce<<std::setw(8)<<random();
        token=nonce.str();owner_ip=req.remote_addr;highest=0;
      }
    }else if(command=="stop") {token.clear();carrier.estop(true);reply=carrier.estop(false);}
    const auto decoded=Json::parse(reply.body);
    const auto message=decoded.contains("error")?decoded["error"].value("message","control failed"):"keyboard_ready";
    res.status=reply.status;
    res.set_content(Json{{"success",reply.status==200},{"message",message},
      {"session_token",token},{"udp_port",port+1}}.dump(),"application/json");
  });
  if(!server.bind_to_port("0.0.0.0",port)) {close(udp);return 2;}
  std::signal(SIGINT,shutdown_signal);std::signal(SIGTERM,shutdown_signal);
  std::thread datagrams([&] {
    char bytes[2048];
    while(running.load()) {
      sockaddr_in source{};socklen_t size=sizeof(source);
      const auto n=recvfrom(udp,bytes,sizeof(bytes),0,reinterpret_cast<sockaddr*>(&source),&size);
      if(n<=0) continue;
      try {
        const auto data=Json::parse(std::string(bytes,n));
        std::lock_guard<std::mutex> session(session_mutex);
        if(token.empty()||data.value("session_token","")!=token||owner_ip!=inet_ntoa(source.sin_addr)||
           !data.contains("command_seq")||!data["command_seq"].is_number_unsigned()||
           !data.contains("x")||!data["x"].is_number()||!data.contains("y")||!data["y"].is_number()) continue;
        const auto seq=data["command_seq"].get<unsigned long long>();
        if(seq<=highest) continue;
        highest=seq;
        const Json move={{"client_id","atlas-relay"},{"command_seq",seq},
          {"linear_x",data["x"].get<double>()*.50},{"linear_y",data["y"].get<double>()*.50},
          {"angular_z",data.value("angular_z",0.0)}};
        const auto reply=carrier.control("move",move.dump());
        const auto decoded=Json::parse(reply.body);
        const auto message=decoded.contains("error")?decoded["error"].value("message","control revoked"):"ok";
        const auto ack=Json{{"session_token",token},{"command_seq",seq},
          {"success",reply.status==200},{"message",message}}.dump();
        sendto(udp,ack.data(),ack.size(),MSG_DONTWAIT,reinterpret_cast<sockaddr*>(&source),size);
      }catch(const std::exception &) {}
    }
  });
  std::thread http([&]{server.listen_after_bind();});
  while(running.load()) std::this_thread::sleep_for(std::chrono::milliseconds(100));
  server.stop();http.join();datagrams.join();close(udp);
}
