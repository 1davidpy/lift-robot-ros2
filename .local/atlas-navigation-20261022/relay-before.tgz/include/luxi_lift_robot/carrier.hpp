#pragma once
#include <chrono>
#include <mutex>
#include <memory>
#include <string>
#include <thread>

namespace luxi_lift_robot {
struct Reply { int status; std::string body; };
class Carrier {
public:
  Carrier(const std::string &type, const std::string &host, int port,
          const std::string &selection_file);
  ~Carrier();
  bool is_lift() const;
  Reply status() const;
  Reply select(const std::string &type);
  Reply control(const std::string &action, const std::string &body);
  Reply estop(bool active);
private:
  using Clock = std::chrono::steady_clock;
  static Reply error(int code, const std::string &message);
  std::string request(const char *path, const std::string &body = "");
  void refresh_locked();
  void stop_locked(const std::string &reason);
  void run();
  mutable std::mutex mutex_;
  std::recursive_mutex io_mutex_;
  struct Datagram;
  std::unique_ptr<Datagram> datagram_;
  std::string type_, host_, selection_file_, holder_, reason_{"等待机器人状态"};
  int port_;
  bool running_{true}, connected_{false}, ready_{false}, armed_{false}, estop_{false};
  double x_{0}, y_{0};
  unsigned long long sequence_{0};
  Clock::time_point heartbeat_{}, command_{}, last_poll_{};
  std::thread worker_;
};
}
