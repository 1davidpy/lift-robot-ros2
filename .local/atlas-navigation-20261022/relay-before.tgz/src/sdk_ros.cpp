// Robot-local SDK transport. The general SDK HTTP server is deliberately absent
// from this path: camera/state requests must not queue a leased keyboard command.
#include <rclcpp/rclcpp.hpp>
#include <luxi_interfaces/srv/command.hpp>
#include <std_msgs/msg/string.hpp>
#include <nlohmann/json.hpp>
#include <chrono>
#include <mutex>
#include <thread>

namespace luxi_lift_robot {
namespace {
using Json=nlohmann::json;
using Clock=std::chrono::steady_clock;
class LocalSdk {
  rclcpp::Node::SharedPtr node_;
  rclcpp::Client<luxi_interfaces::srv::Command>::SharedPtr client_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr state_sub_, status_sub_;
  rclcpp::executors::SingleThreadedExecutor executor_;
  std::thread thread_;
  std::mutex mutex_;
  Json base_=Json::object(), status_=Json::object();
  Clock::time_point status_time_{};
public:
  LocalSdk() {
    node_=std::make_shared<rclcpp::Node>("atlas_carrier_sdk_transport");
    client_=node_->create_client<luxi_interfaces::srv::Command>("/luxi/base/control");
    state_sub_=node_->create_subscription<std_msgs::msg::String>("/luxi/base/state",
      rclcpp::SensorDataQoS().keep_last(1),[this](std_msgs::msg::String::ConstSharedPtr msg) {
        auto value=Json::parse(msg->data,nullptr,false);
        if(!value.is_object()) return;
        std::lock_guard<std::mutex> lock(mutex_);base_=std::move(value);
      });
    status_sub_=node_->create_subscription<std_msgs::msg::String>("/luxi/base/status",
      rclcpp::QoS(1).transient_local(),[this](std_msgs::msg::String::ConstSharedPtr msg) {
        auto value=Json::parse(msg->data,nullptr,false);
        if(!value.is_object()) return;
        std::lock_guard<std::mutex> lock(mutex_);status_=std::move(value);status_time_=Clock::now();
      });
    executor_.add_node(node_);
    thread_=std::thread([this]{executor_.spin();});
  }
  ~LocalSdk() {executor_.cancel();if(thread_.joinable()) thread_.join();rclcpp::shutdown();}
  Json state() {
    Json base,status;
    Clock::time_point received;
    {std::lock_guard<std::mutex> lock(mutex_);base=base_;status=status_;received=status_time_;}
    const auto now=Clock::now();
    const auto now_ns=std::chrono::duration_cast<std::chrono::nanoseconds>(now.time_since_epoch()).count();
    long long stamp=0;
    try {stamp=std::stoll(base.value("receive_mono_ns",std::string("0")));}catch(...) {}
    const auto age=now_ns-stamp;
    base["valid"]=base.value("valid",false)&&stamp>0&&age>=0&&age<250000000;
    status["fresh"]=now-received<std::chrono::milliseconds(500);
    status["feedback_fresh"]=status.value("feedback_fresh",false)&&stamp>0&&age>=0&&age<100000000;
    return {{"base",base},{"base_status",status},
      {"system",{{"services",{{"base",client_->service_is_ready()}}}}},
      {"control_transport","local_ros2"}};
  }
  Json command(const std::string &body) {
    if(!client_->service_is_ready()) throw std::runtime_error("本机 ROS 2 底盘控制服务未就绪");
    const auto doc=Json::parse(body);
    auto request=std::make_shared<luxi_interfaces::srv::Command::Request>();
    request->command=doc.at("command").get<std::string>();
    request->detail=doc.value("detail",std::string());
    auto future=client_->async_send_request(request);
    const auto timeout=std::chrono::milliseconds(request->command=="keyboard_start"?500:120);
    if(future.wait_for(timeout)!=std::future_status::ready) {
      client_->remove_pending_request(future);
      throw std::runtime_error("本机 ROS 2 底盘控制回执超时");
    }
    const auto reply=future.get();
    return {{"success",reply->success},{"message",reply->message}};
  }
};
}
std::string local_sdk_request(const char *path,const std::string &body) {
  static const bool initialized=[] {
    rclcpp::init(0,nullptr,rclcpp::InitOptions{},rclcpp::SignalHandlerOptions::None);
    return true;
  }();
  (void)initialized;
  static LocalSdk sdk;
  if(std::string(path)=="/api/state") return sdk.state().dump();
  if(std::string(path)=="/api/keyboard") return sdk.command(body).dump();
  throw std::runtime_error("未知本机 SDK 操作");
}
}
