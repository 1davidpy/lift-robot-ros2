#include "luxi_lift_robot/carrier.hpp"
#include <curl/curl.h>
#include <yaml-cpp/yaml.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

namespace luxi_lift_robot {
#ifdef LUXI_LOCAL_ROS_SDK
std::string local_sdk_request(const char *path, const std::string &body);
#endif
namespace {
std::string quoted(const std::string &s) {
  std::string out="\"";
  for (unsigned char c:s) {
    if(c=='"'||c=='\\') {out+='\\';out+=c;}
    else if(c=='\n') out+="\\n";
    else if(c=='\r') out+="\\r";
    else if(c=='\t') out+="\\t";
    else if(c<32) out+=' ';
    else out+=c;
  }
  return out+'"';
}
size_t receive(char *p,size_t size,size_t count,void *data) {
  auto &out=*static_cast<std::string*>(data);
  if(out.size()+size*count>1024*1024) return 0;
  out.append(p,size*count); return size*count;
}
bool flag(const YAML::Node &doc,const char *key) {return doc[key] && doc[key].as<bool>();}
// Ownership tolerates a brief browser/LAN stall; motion still expires at 250 ms.
constexpr auto owner_lease = std::chrono::milliseconds(1000);
}
struct Carrier::Datagram {
  int fd{-1};sockaddr_in peer{};std::string token;
  unsigned long long sequence{0},ack_sequence{0};
  Clock::time_point last_ack{Clock::now()};
  Datagram(const std::string &host,int port,const std::string &value):token(value) {
    if(port<1||port>65535||token.empty()) throw std::runtime_error("中继 UDP 会话无效");
    peer.sin_family=AF_INET;peer.sin_port=htons(port);
    if(inet_pton(AF_INET,host.c_str(),&peer.sin_addr)!=1) throw std::runtime_error("中继地址无效");
    fd=socket(AF_INET,SOCK_DGRAM|SOCK_CLOEXEC,0);
    if(fd<0) throw std::runtime_error("无法创建中继 UDP socket");
  }
  ~Datagram(){if(fd>=0) close(fd);}
  void send(double x,double y) {
    std::ostringstream body;
    body<<"{\"session_token\":"<<quoted(token)<<",\"command_seq\":"<<++sequence
        <<",\"x\":"<<x/.05<<",\"y\":"<<y/.05<<"}";
    const auto text=body.str();
    if(sendto(fd,text.data(),text.size(),MSG_DONTWAIT,reinterpret_cast<sockaddr*>(&peer),sizeof(peer))<0)
      throw std::runtime_error("中继 UDP 发送失败");
    char data[2048];sockaddr_in source{};socklen_t size=sizeof(source);
    for(int packet=0;packet<32;++packet) {
      const auto n=recvfrom(fd,data,sizeof(data),MSG_DONTWAIT,reinterpret_cast<sockaddr*>(&source),&size);
      if(n<0) break;
      if(source.sin_addr.s_addr!=peer.sin_addr.s_addr||source.sin_port!=peer.sin_port) continue;
      try {
        const auto ack=YAML::Load(std::string(data,n));
        if(!ack["session_token"]||ack["session_token"].as<std::string>()!=token||!ack["command_seq"]) continue;
        const auto seq=ack["command_seq"].as<unsigned long long>();
        if(seq<=ack_sequence||seq>sequence) continue;
        if(!flag(ack,"success")) throw std::runtime_error(ack["message"]?ack["message"].as<std::string>():"中继已撤销控制权");
        ack_sequence=seq;last_ack=Clock::now();
      }catch(const YAML::Exception &) {continue;}
    }
    if(Clock::now()-last_ack>std::chrono::milliseconds(1000)) throw std::runtime_error("中继 UDP 回执超时");
  }
};
Reply Carrier::error(int code,const std::string &message) {
  return {code,"{\"ok\":false,\"error\":{\"code\":"+quoted(code==400?"BAD_REQUEST":code==409?"CONFLICT":"NOT_READY")+
    ",\"message\":"+quoted(message)+"}}"};
}
Carrier::Carrier(const std::string &type,const std::string &host,int port,const std::string &file)
 :type_(type),host_(host),selection_file_(file),port_(port) {
  if(type!="go2"&&type!="lift_robot") throw std::invalid_argument("Unknown robot_type");
  if(host.empty()||port<1||port>65535) throw std::invalid_argument("Invalid lift robot endpoint");
  static const int initialized=[](){return curl_global_init(CURL_GLOBAL_DEFAULT);}();
  if(initialized!=0) throw std::runtime_error("curl initialization failed");
  worker_=std::thread([this]{run();});
}
Carrier::~Carrier() {
  {std::lock_guard<std::mutex> lock(mutex_);running_=false;stop_locked("后台关闭");}
  if(worker_.joinable()) worker_.join();
}
bool Carrier::is_lift() const {std::lock_guard<std::mutex> lock(mutex_);return type_=="lift_robot";}
std::string Carrier::request(const char *path,const std::string &body) {
  std::lock_guard<std::recursive_mutex> io(io_mutex_);
#ifdef LUXI_LOCAL_ROS_SDK
  if(host_=="127.0.0.1") return local_sdk_request(path,body);
#endif
  // Reuse each calling thread's TCP connection. Opening a new socket for every
  // 50 ms heartbeat adds avoidable Wi-Fi jitter and SDK thread-pool load.
  static thread_local std::unique_ptr<CURL,decltype(&curl_easy_cleanup)> client(curl_easy_init(),curl_easy_cleanup);
  CURL *curl=client.get();
  if(!curl) throw std::runtime_error("HTTP client unavailable");
  curl_easy_reset(curl);
  std::string result,url="http://"+host_+":"+std::to_string(port_)+path;
  curl_easy_setopt(curl,CURLOPT_URL,url.c_str());
  curl_easy_setopt(curl,CURLOPT_PROXY,"");
  // The SDK-side relay is fast; use short LAN connections so a peer's
  // keep-alive request limit cannot delay a leased command on a closing socket.
  if(host_!="127.0.0.1") curl_easy_setopt(curl,CURLOPT_FORBID_REUSE,1L);
  curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L);
  const bool local=host_=="127.0.0.1";
  curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT_MS,local?80L:1500L);
  // Remote HTTP is only ARM/stop/metadata. Velocity and its bounded watchdog
  // use UDP, so TCP may tolerate a lost SYN without extending motion validity.
  const long timeout=body.find("keyboard_start")!=std::string::npos?(local?1000L:3000L):
    body.find("\"stop\"")!=std::string::npos?(local?300L:1500L):(local?150L:2000L);
  curl_easy_setopt(curl,CURLOPT_TIMEOUT_MS,timeout);
  curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,receive);
  curl_easy_setopt(curl,CURLOPT_WRITEDATA,&result);
  curl_slist *headers=nullptr;
  if(!body.empty()) {
    headers=curl_slist_append(headers,"Content-Type: application/json");
    curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers);
    curl_easy_setopt(curl,CURLOPT_POSTFIELDS,body.c_str());
  }
  const auto code=curl_easy_perform(curl);
  long http=0;curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&http);
  curl_slist_free_all(headers);
  if(code!=CURLE_OK) throw std::runtime_error(std::string("机器人连接失败: ")+curl_easy_strerror(code));
  if(http!=200) {
    std::string message="SDK HTTP "+std::to_string(http);
    try {
      const auto doc=YAML::Load(result);
      if(doc.IsMap()&&doc["message"]) message=doc["message"].as<std::string>();
    }catch(const YAML::Exception &) {}
    throw std::runtime_error(message);
  }
  return result;
}
void Carrier::refresh_locked() {
  const auto doc=YAML::Load(request("/api/state"));
  connected_=true;ready_=false;
  const auto bs=doc["base_status"], base=doc["base"], system=doc["system"];
  if(!bs||!base||!system||!system["services"]||!flag(system["services"],"base")) reason_="底盘控制服务未就绪";
  else if(flag(bs,"receive_only")) reason_="底盘为 CAN 只读诊断模式，请在机器人上启用独立底盘控制模式";
  else if(flag(bs,"shared_enable")||flag(bs,"external_control")) reason_="底盘由 Quest/外部控制器管理，请先退出该模式";
  else if(!flag(bs,"fresh")||!flag(bs,"feedback_fresh")||!flag(base,"valid")) reason_="底盘反馈已过期或无效";
  else if(base["flag_stop"] && base["flag_stop"].as<int>()!=0) reason_="底盘反馈 FlagStop 非零";
  else if(flag(bs,"enabled")&&!armed_) reason_="底盘已由其他控制器使能，请先停车退出";
  else {ready_=true;reason_=armed_?"键盘控制已使能":"底盘就绪，等待接管";}
}
void Carrier::stop_locked(const std::string &reason) {
  const bool owned=armed_;
  if(owned && reason!="已释放控制权") std::clog<<"[carrier] control revoked: "<<reason<<std::endl;
  armed_=false;holder_.clear();x_=y_=0;sequence_=0;reason_=reason;
  datagram_.reset();
  if(owned) {try {request("/api/keyboard","{\"command\":\"stop\"}");}catch(...) {}}
}
Reply Carrier::status() const {
  std::lock_guard<std::mutex> lock(mutex_);
  const bool lift=type_=="lift_robot";
  std::ostringstream out;
  out<<"{\"ok\":true,\"robot_type\":"<<quoted(type_)<<",\"label\":"<<quoted(lift?"升降机器人 · R680 全向底盘":"Go2 四足机器人")
     <<",\"available\":[{\"id\":\"go2\",\"label\":\"Go2 四足机器人\"},{\"id\":\"lift_robot\",\"label\":\"升降机器人 · 全向底盘\"}]"
     <<",\"connected\":"<<(connected_?"true":"false")<<",\"ready\":"<<(ready_?"true":"false")
     <<",\"armed\":"<<(armed_?"true":"false")<<",\"reason\":"<<quoted(reason_)
     <<",\"holder_client_id\":"<<quoted(holder_)<<",\"heartbeat_timeout_ms\":"<<owner_lease.count()
     <<",\"linear_limit\":"<<(lift?.05:.25)<<",\"angular_limit\":"<<(lift?0:.35)
     <<",\"holonomic\":"<<(lift?"true":"false")<<",\"estop\":"<<(estop_?"true":"false")<<"}";
  return {200,out.str()};
}
Reply Carrier::select(const std::string &type) {
  std::lock_guard<std::mutex> lock(mutex_);
  if(type!="go2"&&type!="lift_robot") return error(400,"未知机器人载体");
  if(!holder_.empty()||armed_) return error(409,"请先释放控制权，再切换载体");
  if(type==type_) return {200,"{\"ok\":true}"};
  try {
    const std::filesystem::path path(selection_file_);
    std::filesystem::create_directories(path.parent_path());
    YAML::Node doc=std::filesystem::exists(path)?YAML::LoadFile(path.string()):YAML::Node(YAML::NodeType::Map);
    doc["web_api_node"]["ros__parameters"]["robot_type"]=type;
    const auto temp=path.string()+".next";
    {std::ofstream stream(temp);stream.exceptions(std::ios::badbit|std::ios::failbit);stream<<doc;}
    std::filesystem::rename(temp,path);
    type_=type;ready_=false;connected_=false;reason_="载体已选择，等待状态";last_poll_={};
    return {200,"{\"ok\":true}"};
  }catch(const std::exception &e) {return error(503,std::string("保存本机载体选择失败: ")+e.what());}
}
Reply Carrier::estop(bool active) {
  std::lock_guard<std::mutex> lock(mutex_);estop_=active;
  if(active) stop_locked("软件停止已锁定");
  return {200,"{\"ok\":true}"};
}
Reply Carrier::control(const std::string &action,const std::string &body) {
  std::lock_guard<std::mutex> lock(mutex_);
  if(type_!="lift_robot") return error(409,"当前载体不是全向底盘，请重新取得对应载体控制权");
  try {
    const auto doc=YAML::Load(body);
    const auto id=doc["client_id"]?doc["client_id"].as<std::string>():"";
    if(id.empty()||id.size()>64) return error(400,"client_id 无效");
    const auto now=Clock::now();
    if(!holder_.empty() && now-heartbeat_>owner_lease) stop_locked("控制权心跳超时");
    if(action=="acquire") {
      if(!holder_.empty()&&holder_!=id) return error(409,"控制权由其他客户端持有");
      if(estop_) return error(409,"请先解除软件停止，再接管");
      if(!armed_) {
        refresh_locked();if(!ready_) return error(503,reason_);
        // Never retry an uncertain ARM: revoke it and require an explicit new acquire.
        try {
          const auto ack=YAML::Load(request("/api/keyboard","{\"command\":\"keyboard_start\"}"));
          if(!flag(ack,"success")) return error(503,"SDK 未确认键盘使能");
          if(ack["session_token"] && ack["udp_port"]) {
            datagram_=std::make_unique<Datagram>(host_,ack["udp_port"].as<int>(),ack["session_token"].as<std::string>());
          }else if(host_!="127.0.0.1") throw std::runtime_error("请先部署机器人本地 UDP 控制中继");
        }catch(const std::exception &e) {
          try {request("/api/keyboard","{\"command\":\"stop\"}");}catch(...) {}
          throw;
        }
        armed_=true;sequence_=0;command_=Clock::now();x_=y_=0;reason_="键盘控制已使能";
      }
      holder_=id;heartbeat_=Clock::now();
      return {200,"{\"ok\":true,\"granted\":true,\"client_id\":"+quoted(id)+",\"expires_in_ms\":1000}"};
    }
    if(holder_!=id||!armed_) return error(409,"控制权已失效，请重新接管");
    if(action=="release") {stop_locked("已释放控制权");return {200,"{\"ok\":true,\"released\":true}"};}
    if(action=="heartbeat") {heartbeat_=now;return {200,"{\"ok\":true,\"expires_in_ms\":1000}"};}
    if(action!="move") return error(400,"未知控制操作");
    const double x=doc["linear_x"]?doc["linear_x"].as<double>():0;
    const double y=doc["linear_y"]?doc["linear_y"].as<double>():0;
    const double z=doc["angular_z"]?doc["angular_z"].as<double>():0;
    const double seq=doc["command_seq"]?doc["command_seq"].as<double>():0;
    if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)||std::hypot(x,y)>.050001||z!=0||
       !std::isfinite(seq)||seq<1||seq>9007199254740991.0||std::floor(seq)!=seq) return error(400,"全向底盘仅支持限速 0.05 m/s 的平移和有效命令序号");
    if(seq<=sequence_) return {200,"{\"ok\":true,\"published\":false,\"stale\":true}"};
    sequence_=static_cast<unsigned long long>(seq);x_=x;y_=y;command_=heartbeat_=now;
    return {200,"{\"ok\":true,\"published\":true,\"stale\":false}"};
  }catch(const YAML::Exception &e) {return error(400,std::string("请求格式错误: ")+e.what());}
   catch(const std::exception &e) {connected_=ready_=false;stop_locked(e.what());return error(503,e.what());}
}
void Carrier::run() {
  while(true) {
    const auto start=Clock::now();
    {
      std::unique_lock<std::mutex> lock(mutex_);
      if(!running_) break;
      if(type_=="lift_robot") {
        try {
          if(armed_ && start-heartbeat_>owner_lease) stop_locked("控制权心跳超时");
          // During control the SDK's own feedback/keyboard watchdogs enforce
          // readiness; do not put large status snapshots ahead of its 200 ms lease.
          if(!armed_ && start-last_poll_>std::chrono::milliseconds(500)) {
            refresh_locked();last_poll_=start;
            if(armed_&&!ready_) stop_locked(reason_);
          }
          if(armed_) {
            if(start-command_>std::chrono::milliseconds(250)) x_=y_=0;
            if(datagram_) {
              datagram_->send(x_,y_);
            }else {
            std::ostringstream body;
            body<<"{\"command\":\"keyboard\",\"detail\":\"["<<x_/.05<<","<<y_/.05<<"]\"}";
            const auto owner=holder_;
            std::string failure;
            // Take transport ownership before unlocking state. Stop/new ARM
            // therefore cannot overtake this command, while browser heartbeat
            // and status requests never wait on a network round trip.
            std::unique_lock<std::recursive_mutex> io(io_mutex_);
            lock.unlock();
            try {
              const auto ack=YAML::Load(request("/api/keyboard",body.str()));
              if(!flag(ack,"success")) failure="SDK 拒绝键盘指令: "+(ack["message"]?ack["message"].as<std::string>():"未提供原因");
            }catch(const std::exception &e) {failure=e.what();}
            io.unlock();
            lock.lock();
            if(armed_&&holder_==owner&&!failure.empty()) throw std::runtime_error(failure);
            }
          }
        }catch(const std::exception &e) {connected_=ready_=false;stop_locked(e.what());last_poll_=start;}
      }
    }
    std::this_thread::sleep_until(start+std::chrono::milliseconds(50));
  }
}
}
